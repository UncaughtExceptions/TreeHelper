package com.lizhenpeng.helper.test;

import com.lizhenpeng.helper.AbstractNode;

public class BaseNode extends AbstractNode<BaseNode>{
	
	private String menuFunction;
	
	public BaseNode(String parentId,String id,String functionName) {
		this.setParentId(parentId);
		this.setId(id);
		this.menuFunction = functionName;
	}
	
	public String getName() {
		return menuFunction;
	}
}
