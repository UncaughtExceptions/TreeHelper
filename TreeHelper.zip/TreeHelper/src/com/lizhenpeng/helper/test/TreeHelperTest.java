package com.lizhenpeng.helper.test;

import java.util.ArrayList;
import java.util.List;

import com.lizhenpeng.helper.TreeHelper;

public class TreeHelperTest {
	
	private static int spaceNum = 0;

	public static void main(String[] args) {
		TreeHelper<BaseNode> helper = new TreeHelper<>("-1"); //设置父节点标志
		List<BaseNode> list = new ArrayList<>();
		list.add(new BaseNode("-1","edit","编辑功能"));
		list.add(new BaseNode("edit","100","编辑功能1"));
		list.add(new BaseNode("edit","200","编辑功能2"));
		list.add(new BaseNode("-1","add","增加功能"));
		list.add(new BaseNode("add","300","增加功能1"));
		list.add(new BaseNode("add","300","增加功能2"));
		list.add(new BaseNode("-1","delete","删除功能"));
		list.add(new BaseNode("100","100_1","编辑功能1_1"));
		list.add(new BaseNode("100","100_2","编辑功能1_2"));
		list.add(new BaseNode("100_2","100_2_1","编辑功能1_2_1"));
		list.add(new BaseNode("200","100_2_1","编辑功能2_1"));
		list.add(new BaseNode("100_1","100_1_1","编辑功能1_1_1"));
		//生成树型结构
		List<BaseNode> tree = helper.createTree(list);
		traverList(tree,spaceNum);//遍历树
	}
	
	public static void traverList(List<BaseNode> list,int space) {
		if(list == null || list.size() == 0) {
			spaceNum --;
			return;
		}
		for(BaseNode node : list) {
			for(int index = 0; index < 2*space; index++) {
				System.out.print(" ");
			}
			System.out.println(node.getName());
			traverList(node.getChild(),++spaceNum);
		}
	}

}
