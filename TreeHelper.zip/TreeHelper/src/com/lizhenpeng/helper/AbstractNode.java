package com.lizhenpeng.helper;

import java.util.List;

/**
 * 抽象节点
 * @author UncaughtExceptions
 */
public abstract class AbstractNode <T extends AbstractNode> {
	
	private String id;
	private String parentId;
	private List<T> child;
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getParentId() {
		return parentId;
	}
	
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public List<T> getChild() {
		return child;
	}

	public void setChild(List<T> child) {
		this.child = child;
	}
	
}
