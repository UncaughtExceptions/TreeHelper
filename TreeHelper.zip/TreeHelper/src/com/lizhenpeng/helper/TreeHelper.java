package com.lizhenpeng.helper;

import java.util.ArrayList;
import java.util.List;

/**
 * 创建节点树
 * @author UncaughtExceptions
 */
public class TreeHelper <T extends AbstractNode> {
	
	private String parentNodeFlag;
	
	public TreeHelper(String parentFlag) {
		this.parentNodeFlag = parentFlag;
	}
	
	/**
	 * 递归创建树
	 * @param list
	 * @return
	 */
	public List<T> createTree(List<T> nodeList){
		List<T> rootNodeList = findRootNode(nodeList);
		recursionCreate(rootNodeList,nodeList);
		return rootNodeList;
	}
	
	/**
	 * 查询根节点
	 * @param nodeList
	 * @return
	 */
	private List<T> findRootNode(List<T> nodeList){
		List<T> rootList = new ArrayList<T>();
		for(T item : nodeList) {
			if(item != null) {
				if(item.getParentId().equals(parentNodeFlag)) {
					rootList.add(item);
				}
			}
		}
		return rootList;
	}
	
	/**
	 * 查询子节点
	 * @return
	 */	
	public List<T> findChildNodes(T parentNode,List<T> nodeList){
		List<T> child = new ArrayList<T>();
		for(T item : nodeList) {
			if(item != null) {
				if(item.getParentId().equals(parentNode.getId())) {
					child.add(item);
				}
			}
		}
		return child;
	}
	
	/**
	 * 递归查询子节点
	 */
	private void recursionCreate(List<T> parentNodeList,List<T> nodeList) {
		for(T item : parentNodeList) {
			List<T> childNodeList = findChildNodes(item,nodeList);
			item.setChild(childNodeList);
			recursionCreate(item.getChild(),nodeList);
		}
	}
	
}
